import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button, Input, SegmentedControl } from "glisse";

const KEY = "team-assign-v1";
const DEF = {
  total: 37,
  names: {},
  teams: [
    { id: "fb", name: "Football", cap: 9, h: 145, m: [3, 8, 7, 6, 9, 11, 2, 10] },
    { id: "cb", name: "Chairball", cap: 9, h: 211, m: [18, 28, 22, 34, 26, 24, 21, 31] },
    { id: "cam", name: "Cameraman", cap: 5, h: 270, m: [16, 35, 23, 27, 20] },
    { id: "sh", name: "Show", cap: 7, h: 330, m: [4, 19, 24, 34, 28, 13, 1] },
    { id: "st", name: "Staff", cap: 6, h: 28, m: [25, 17, 33, 37, 30, 29] },
    { id: "ch", name: "Cheer", cap: 4, h: 48, m: [5, 15, 14, 12] },
  ],
};
const clone = (x) => JSON.parse(JSON.stringify(x));
const load = () => {
  try {
    const r = localStorage.getItem(KEY);
    if (r) return JSON.parse(r);
  } catch (e) {}
  return clone(DEF);
};
const asc = (a, b) => a - b;

/* icons (plain inline SVG) */
const sv = (d, extra) => (
  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    {d}
    {extra}
  </svg>
);
const ListIcon = sv(<path d="M5 7h14M5 12h14M5 17h9" />);
const SlidersIcon = sv(<path d="M4 8h9M17 8h3M4 16h3M11 16h9" />, <><circle cx="15" cy="8" r="2" /><circle cx="9" cy="16" r="2" /></>);
const Check = (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 10.5l4 4 8-9" />
  </svg>
);

/* Apple-style spring (damping ratio + response), starts from the live value + velocity */
function spring(from, to, v, resp, damp, fn, end) {
  const k = Math.pow((2 * Math.PI) / resp, 2), c = (4 * Math.PI * damp) / resp;
  let x = from, t0 = performance.now(), raf = 0, dead = false;
  const step = (t) => {
    if (dead) return;
    const dt = Math.min((t - t0) / 1000, 1 / 30);
    t0 = t;
    for (let i = 0; i < 4; i++) { v += ((-k * (x - to) - c * v) * dt) / 4; x += (v * dt) / 4; }
    if (Math.abs(x - to) < 0.4 && Math.abs(v) < 8) { fn(to); end && end(); return; }
    fn(x);
    raf = requestAnimationFrame(step);
  };
  raf = requestAnimationFrame(step);
  return () => { dead = true; cancelAnimationFrame(raf); };
}

/* bottom sheet: drag to dismiss, rubber-band, momentum projection, spring */
function Sheet({ content, title, onClose }) {
  const open = !!content;
  const [mounted, setMounted] = useState(false);
  const last = useRef({ content: null, title: "" });
  if (content) last.current = { content, title };
  const el = useRef(null), scrim = useRef(null);
  const st = useRef({ y: 0, cancel: null, drag: null, hist: [], vel: 0 });

  const setY = useCallback((y) => {
    st.current.y = y;
    const e = el.current;
    if (!e) return;
    e.style.transform = `translateY(${y}px)`;
    if (scrim.current) scrim.current.style.opacity = Math.max(0, Math.min(1, 1 - y / (st.current.h || 1)));
  }, []);

  useEffect(() => { if (open) setMounted(true); }, [open]);
  useEffect(() => {
    const e = el.current;
    if (!mounted || !e) return;
    const s = st.current;
    s.cancel && s.cancel();
    const h = e.offsetHeight;
    s.h = h;
    if (open) {
      if (s.y === 0 && !s.shown) { setY(h + 30); s.shown = true; }
      s.cancel = spring(s.y, 0, 0, 0.42, 1, setY);
    } else {
      s.cancel = spring(s.y, h + 30, s.vel || 0, 0.35, 1, setY, () => { s.shown = false; s.vel = 0; s.y = 0; setMounted(false); });
    }
  }, [open, mounted, setY]);

  const down = (e) => {
    if (e.target.closest(".done")) return;
    const s = st.current;
    s.cancel && s.cancel();
    e.currentTarget.setPointerCapture(e.pointerId);
    s.drag = { sy: e.clientY, y0: s.y };
    s.hist = [{ y: e.clientY, t: e.timeStamp }];
  };
  const move = (e) => {
    const s = st.current;
    if (!s.drag) return;
    let y = s.drag.y0 + (e.clientY - s.drag.sy);
    if (y < 0) { const o = -y, D = s.h; y = -(o * D * 0.55) / (D + 0.55 * o); }
    setY(y);
    s.hist.push({ y: e.clientY, t: e.timeStamp });
    if (s.hist.length > 5) s.hist.shift();
  };
  const up = () => {
    const s = st.current;
    if (!s.drag) return;
    s.drag = null;
    const a = s.hist[0], b = s.hist[s.hist.length - 1];
    const v = b.t > a.t ? ((b.y - a.y) / (b.t - a.t)) * 1000 : 0;
    const proj = s.y + (v / 1000) * 0.998 / (1 - 0.998);
    if (proj > s.h * 0.5) { s.vel = v; onClose(); }
    else s.cancel = spring(s.y, 0, v, 0.35, 0.8, setY);
  };

  if (!mounted) return null;
  return (
    <>
      <div className="scrim" ref={scrim} onPointerDown={() => onClose()} />
      <div className="sheet" ref={el}>
        <div className="gz" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
          <div className="gr" />
          <div className="sh">
            <h2>{last.current.title}</h2>
            <button className="done press" onClick={() => onClose()}>เสร็จ</button>
          </div>
        </div>
        <div className="sb">{last.current.content}</div>
      </div>
    </>
  );
}

function SettingsForm({ S, onApply, onReset }) {
  const [total, setTotal] = useState(S.total);
  const [caps, setCaps] = useState(S.teams.map((t) => t.cap));
  return (
    <>
      <p>จำนวนคนทั้งหมด และที่นั่งของแต่ละทีม</p>
      <div className="tg">
        <label className="fr"><span>จำนวนคนทั้งหมด</span>
          <input type="number" inputMode="numeric" min="1" max="99" value={total} onChange={(e) => setTotal(e.target.value)} />
        </label>
      </div>
      <div className="tg">
        {S.teams.map((t, i) => (
          <label className="fr" key={t.id}>
            <span style={{ display: "flex", alignItems: "center", gap: 10 }}><i className="dot" style={{ "--h": t.h }} />{t.name}</span>
            <input type="number" inputMode="numeric" min="0" max="99" value={caps[i]} onChange={(e) => setCaps(caps.map((c, j) => (j === i ? e.target.value : c)))} />
          </label>
        ))}
      </div>
      <button className="btn press" onClick={() => onApply(parseInt(total), caps.map((c) => parseInt(c)))}>บันทึก</button>
      <button className="btn r press" onClick={onReset}>รีเซ็ตเป็นข้อมูลจากบอร์ด</button>
    </>
  );
}

export default function App() {
  const [S, setS] = useState(load);
  const [tab, setTab] = useState("team");
  const [sheet, setSheet] = useState(null);
  const [toast, setToast] = useState("");
  const [sc, setSc] = useState(false);
  const tt = useRef(0);

  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }, [S]);
  useEffect(() => {
    const f = () => setSc(window.scrollY > 44);
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  const say = (t) => { setToast(t); clearTimeout(tt.current); tt.current = setTimeout(() => setToast(""), 2400); };
  const buzz = () => { try { navigator.vibrate && navigator.vibrate(8); } catch (e) {} };
  const upd = (fn) => setS((p) => { const n = clone(p); fn(n); return n; });
  const teamsOf = (n) => S.teams.filter((t) => t.m.includes(n));
  const nums = Array.from({ length: S.total }, (_, i) => i + 1);
  const { un, dup, as } = useMemo(() => {
    const un = [], dup = [];
    for (let n = 1; n <= S.total; n++) { const c = S.teams.filter((t) => t.m.includes(n)).length; if (!c) un.push(n); else if (c > 1) dup.push(n); }
    return { un, dup, as: S.total - un.length };
  }, [S]);

  const toggle = (id, n) => { buzz(); upd((d) => { const t = d.teams.find((x) => x.id === id); const i = t.m.indexOf(n); i > -1 ? t.m.splice(i, 1) : t.m.push(n); }); };
  const setName = (n, v) => upd((d) => { v = v.trim(); v ? (d.names[n] = v) : delete d.names[n]; });

  const auto = () => {
    if (!un.length) return say("ทุกเบอร์มีทีมแล้ว");
    const pool = un.slice();
    for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    let done = 0; const left = [];
    upd((d) => {
      pool.forEach((n) => {
        let best = null;
        d.teams.forEach((t) => { const f = t.cap - t.m.length; if (f > 0 && (!best || f > best.cap - best.m.length)) best = t; });
        if (best) { best.m.push(n); done++; } else left.push(n);
      });
    });
    buzz();
    say(left.length ? `จัดให้ ${done} คน · เต็มแล้ว เหลือ ${left.join(", ")}` : `จัดให้ ${pool.length} คนแล้ว`);
  };

  const summaryText = () => {
    let t = "หน่วยที่ 5\n\n";
    S.teams.forEach((x) => { t += `${x.name} (${x.m.length}/${x.cap}): ${x.m.slice().sort(asc).map((n) => (S.names[n] ? `${n} ${S.names[n]}` : n)).join(", ")}\n`; });
    if (un.length) t += `\nยังไม่มีทีม: ${un.join(", ")}`;
    return t;
  };
  const copy = async (text) => { try { await navigator.clipboard.writeText(text); say("คัดลอกแล้ว"); } catch (e) { say("คัดลอกไม่ได้ — กดค้างที่ข้อความแล้วเลือกคัดลอก"); } };

  let sc_content = null, sc_title = "";
  if (sheet) {
    if (sheet.k === "team") {
      const t = S.teams.find((x) => x.id === sheet.id);
      sc_title = `${t.name} · ${t.m.length}/${t.cap}`;
      sc_content = (
        <>
          <p>แตะเบอร์เพื่อเพิ่มหรือเอาออก · จุดส้ม = อยู่ทีมอื่นแล้ว</p>
          <div className="pick" style={{ "--h": t.h }}>
            {nums.map((n) => (
              <button key={n} className={"press" + (t.m.includes(n) ? " in" : "")} onClick={() => toggle(t.id, n)}>
                {n}{teamsOf(n).some((x) => x.id !== t.id) && <i />}
              </button>
            ))}
          </div>
        </>
      );
    } else if (sheet.k === "stu") {
      const n = sheet.n;
      sc_title = `เบอร์ ${n}`;
      sc_content = (
        <>
          <Input type="text" aria-label="ชื่อ" placeholder="ชื่อ (ไม่ใส่ก็ได้)" value={S.names[n] || ""} onValueChange={(v) => setName(n, v)} />
          <div className="tg">
            {S.teams.map((t) => (
              <button key={t.id} className="press" onClick={() => toggle(t.id, n)}>
                <span className="dot" style={{ "--h": t.h }} />
                <span>{t.name}</span>
                <em>{t.m.length}/{t.cap}</em>
                {t.m.includes(n) ? Check : <span className="ph" />}
              </button>
            ))}
          </div>
          <p style={{ margin: "12px 4px 0" }}>เลือกได้หลายทีมถ้าจำเป็น</p>
        </>
      );
    } else if (sheet.k === "sum") {
      sc_title = "สรุปรายชื่อ";
      const text = summaryText();
      sc_content = (
        <>
          <textarea readOnly value={text} />
          <button className="btn press" onClick={() => copy(text)}>คัดลอก</button>
        </>
      );
    } else if (sheet.k === "set") {
      sc_title = "ตั้งค่า";
      sc_content = (
        <SettingsForm
          S={S}
          onApply={(total, caps) => {
            upd((d) => {
              if (total > 0) d.total = total;
              d.teams.forEach((t, i) => { if (caps[i] >= 0) t.cap = caps[i]; t.m = t.m.filter((n) => n <= d.total); });
            });
            setSheet(null); say("บันทึกแล้ว");
          }}
          onReset={() => { if (confirm("รีเซ็ตทั้งหมดกลับเป็นข้อมูลจากไวท์บอร์ด?")) { setS(clone(DEF)); setSheet(null); } }}
        />
      );
    }
  }

  return (
    <>
      <div className="wp" data-glisse-backdrop />
      <div className={"nav" + (sc ? " sc" : "")}><span>หน่วยที่ 5</span></div>
      <div className="wrap">
        <h1>จัดคนเข้าทีม</h1>
        <p className="sub">หน่วยที่ 5 · ข้อมูลตั้งต้นจากไวท์บอร์ด</p>

        <div className="glass stats">
          <div className="stat"><b>{as}<span style={{ fontSize: 15, fontWeight: 500 }}> / {S.total}</span></b><span>จัดแล้ว</span></div>
          <div className="stat"><b>{un.length}</b><span>ยังไม่มีทีม</span></div>
          <div className={"stat" + (dup.length ? " w" : "")}><b>{dup.length}</b><span>อยู่หลายทีม</span></div>
        </div>
        {dup.length > 0 && <div className="call">เบอร์ {dup.join(", ")} อยู่มากกว่า 1 ทีม · แตะที่เบอร์เพื่อเลือก</div>}
        {un.length > 0 && <div className="call n">ยังไม่มีทีม: {un.join(", ")}</div>}

        <div className="segw">
          <SegmentedControl
            aria-label="มุมมอง"
            items={[{ value: "team", label: "ตามทีม" }, { value: "num", label: "ตามเบอร์" }]}
            value={tab}
            onValueChange={setTab}
          />
        </div>

        {tab === "team" ? (
          S.teams.map((t) => (
            <div className="glass team" key={t.id} style={{ "--h": t.h }}>
              <div className="th">
                <i className="dot" /><b>{t.name}</b>
                <span className={"cnt" + (t.m.length > t.cap ? " over" : t.m.length === t.cap ? " full" : "")}>{t.m.length} / {t.cap}</span>
              </div>
              <div className="prog"><i style={{ width: `${t.cap ? Math.min(100, (t.m.length / t.cap) * 100) : 0}%` }} /></div>
              <div className="chips">
                {t.m.slice().sort(asc).map((n) => (
                  <button key={n} className={"chip press" + (teamsOf(n).length > 1 ? " dup" : "")} onClick={() => setSheet({ k: "stu", n })}>
                    {n}{S.names[n] && <small>{S.names[n]}</small>}
                  </button>
                ))}
                <button className="add press" onClick={() => setSheet({ k: "team", id: t.id })}>+ เพิ่ม</button>
              </div>
            </div>
          ))
        ) : (
          <>
            <p className="legend">เส้นประ = ยังไม่มีทีม · ส้ม = อยู่หลายทีม · สี = ทีมเดียว</p>
            <div className="grid">
              {nums.map((n) => {
                const ts = teamsOf(n);
                const cls = ts.length === 0 ? "un" : ts.length === 1 ? "one" : "dup";
                return (
                  <button key={n} className={"cell press " + cls} style={ts.length === 1 ? { "--h": ts[0].h } : undefined} onClick={() => setSheet({ k: "stu", n })}>
                    <b>{n}</b><span>{S.names[n] || (ts.length === 0 ? "ว่าง" : ts.length === 1 ? ts[0].name : `${ts.length} ทีม`)}</span>
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>

      <div className="bar">
        <Button variant="filled" onClick={auto}>จัดอัตโนมัติ</Button>
        <Button icon={ListIcon} aria-label="สรุปรายชื่อ" onClick={() => setSheet({ k: "sum" })} />
        <Button icon={SlidersIcon} aria-label="ตั้งค่า" onClick={() => setSheet({ k: "set" })} />
      </div>

      <Sheet content={sc_content} title={sc_title} onClose={() => setSheet(null)} />
      <div className={"toast" + (toast ? " on" : "")}>{toast}</div>
    </>
  );
}
